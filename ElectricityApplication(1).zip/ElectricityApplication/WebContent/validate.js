
function validate()
{
	var lastMonth=document.getElementById("lastmonthread").value;
	var currentMonth=document.getElementById("currentmonthread").value;
	if(lastMonth>currentMonth){
		alert("current month reading cant be less than last month reading");
		return false;
	}
	else
		{
		return true;
		}

}