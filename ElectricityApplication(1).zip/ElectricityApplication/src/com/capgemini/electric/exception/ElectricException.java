package com.capgemini.electric.exception;

public class ElectricException extends Exception {
String excep=null;
	public ElectricException(String str)
{
	excep=str;
}
	public String toString(){
		return excep;
	}
}
