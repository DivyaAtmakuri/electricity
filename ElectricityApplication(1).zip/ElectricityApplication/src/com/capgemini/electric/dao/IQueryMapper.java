package com.capgemini.electric.dao;

public interface IQueryMapper {
public final static String RETRIEVE_USER_DATA="select count(*) from consumers where consumer_num=?";
public final static String RETRIEVE_CONSUMERS="select * FROM consumers";
public final static String INSERT_BILL_DATA="INSERT INTO billdetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
public final static String RETRIEVE_BILL_DETAILS="select * FROM billdetails WHERE consumer_num=?";
}
