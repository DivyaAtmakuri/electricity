package com.capgemini.electric.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.electric.bean.*;
import com.capgemini.electric.exception.ElectricException;
import com.capgemini.electric.util.DBConnection;


public class ElectricImplDAO implements IElectricInterfaceDAO{


	@Override
	public void addBillDetails(ElectricBean as) throws ElectricException, SQLException {
		Connection con=null;
		PreparedStatement stmt=null;
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.INSERT_BILL_DATA);
			stmt.setInt(1, as.getConsumerNo());
			stmt.setDouble(2, as.getCurReading());
			stmt.setDouble(3, as.getUnits());
			stmt.setDouble(4, as.getNetAmount());
			
			int queryResult=stmt.executeUpdate();
			if(queryResult==0)
			{
				throw new ElectricException("Data Insertion Failed.");
			}
			else
			{
				System.out.println("Data Inserted Successfully.");
			}
			
			con.close();
		
			stmt.close();
	}

	@Override
	public boolean validate(int consumerNo) throws SQLException, ElectricException {
		Connection con=null;
		PreparedStatement stmt=null;
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.RETRIEVE_USER_DATA);
			stmt.setInt(1, consumerNo);
			ResultSet rs=stmt.executeQuery();
			rs.next();
			if(rs.getInt(1)>0){
				return true;
			}
		
			con.close();
		
			stmt.close();
		return false;
	}

	@Override
	public ArrayList displayConsumers() throws SQLException, ElectricException {
		Connection con=null;
		PreparedStatement stmt=null;
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.RETRIEVE_CONSUMERS);
			ResultSet rs=stmt.executeQuery();
			ArrayList l=new ArrayList();
			if(rs!=null){
			while(rs.next()){
					ConsumerBean c=new ConsumerBean();
					c.setConsumerNo(rs.getString(1));
					c.setConsumerName(rs.getString(2));
					c.setAddress(rs.getString(3));
					l.add(c);
			}
		}
			con.close();
		
			stmt.close();
	return l;
	}

	@Override
	public ArrayList displayBills(int consumerno) throws SQLException, ElectricException {
		Connection con=null;
		PreparedStatement stmt=null;
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.RETRIEVE_BILL_DETAILS);
			stmt.setInt(1, consumerno);
			ResultSet rs=stmt.executeQuery();
			ArrayList l=new ArrayList();
			if(rs!=null){
			while(rs.next()){
					BillBean b=new BillBean();
					b.setBillNo(rs.getInt(1));
					
					b.setConsumerNo(rs.getInt(2));
					b.setCurrReading(rs.getDouble(3));
					b.setUnitsConsumed(rs.getDouble(4));
					b.setNetAmount(rs.getDouble(5));
					b.setBillDate(rs.getDate(6));
					l.add(b);
			}
		}
			con.close();
		
			stmt.close();
	return l;
	}

	}
	

		


