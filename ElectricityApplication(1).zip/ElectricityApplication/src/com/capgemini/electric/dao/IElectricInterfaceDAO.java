package com.capgemini.electric.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.electric.bean.ElectricBean;
import com.capgemini.electric.exception.ElectricException;

public interface IElectricInterfaceDAO {
	public void addBillDetails(ElectricBean as) throws ElectricException, SQLException;
	public boolean validate(int consumerNo) throws SQLException, ElectricException;
	public ArrayList displayConsumers() throws SQLException, ElectricException;
	public ArrayList displayBills(int consumerno) throws SQLException, ElectricException;
}
