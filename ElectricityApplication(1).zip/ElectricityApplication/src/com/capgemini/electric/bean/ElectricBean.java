package com.capgemini.electric.bean;

import java.sql.Date;

public class ElectricBean {
	int consumerNo,billNum;
	double curReading,units,netAmount;
	Date d;

	

	public int getConsumerNo() {
		return consumerNo;
	}

	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}

	public double getCurReading() {
		return curReading;
	}

	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}

	public double getUnits() {
		return units;
	}

	public void setUnits(double units) {
		this.units = units;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public int getBillNum() {
		return billNum;
	}

	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}

	public Date getD() {
		return d;
	}

	public void setD(Date d) {
		this.d = d;
	}

	
	

}
