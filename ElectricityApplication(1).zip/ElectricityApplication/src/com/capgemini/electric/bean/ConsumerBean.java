package com.capgemini.electric.bean;

public class ConsumerBean {
String consumerNo,consumerName,address;

public String getConsumerNo() {
	return consumerNo;
}

public void setConsumerNo(String consumerNo) {
	this.consumerNo = consumerNo;
}

public String getConsumerName() {
	return consumerName;
}

public void setConsumerName(String consumerName) {
	this.consumerName = consumerName;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

}
