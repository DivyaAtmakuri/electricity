package com.capgemini.electric.bean;

import java.sql.Date;

public class BillBean {
int billNo,consumerNo;
double unitsConsumed,currReading,netAmount;
public double getNetAmount() {
	return netAmount;
}
public void setNetAmount(double netAmount) {
	this.netAmount = netAmount;
}
Date billDate;
public int getBillNo() {
	return billNo;
}
public void setBillNo(int billNo) {
	this.billNo = billNo;
}
public int getConsumerNo() {
	return consumerNo;
}
public void setConsumerNo(int consumerNo) {
	this.consumerNo = consumerNo;
}
public double getUnitsConsumed() {
	return unitsConsumed;
}
public void setUnitsConsumed(double unitsConsumed) {
	this.unitsConsumed = unitsConsumed;
}
public double getCurrReading() {
	return currReading;
}
public void setCurrReading(double currReading) {
	this.currReading = currReading;
}
public Date getBillDate() {
	return billDate;
}
public void setBillDate(Date billDate) {
	this.billDate = billDate;
}



}
