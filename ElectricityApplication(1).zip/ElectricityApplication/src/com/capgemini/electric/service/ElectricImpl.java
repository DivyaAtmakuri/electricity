package com.capgemini.electric.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.electric.bean.ElectricBean;
import com.capgemini.electric.dao.*;
import com.capgemini.electric.exception.ElectricException;


public class ElectricImpl implements IElectricInterface{
	@Override
	public void addBillDetails(ElectricBean as) throws ElectricException,
			SQLException {
			IElectricInterfaceDAO ie=new ElectricImplDAO();
			ie.addBillDetails(as);
	}

	@Override
	public boolean validate(int consumerNo) throws SQLException, ElectricException{
		IElectricInterfaceDAO ie=new ElectricImplDAO();
		return ie.validate(consumerNo);
	}

	@Override
	public ArrayList displayConsumers() throws SQLException, ElectricException {
		IElectricInterfaceDAO ie=new ElectricImplDAO();
		return ie.displayConsumers();
		
	}

	@Override
	public ArrayList displayBills(int consumerno) throws SQLException, ElectricException {
		IElectricInterfaceDAO ie=new ElectricImplDAO();
		return ie.displayBills(consumerno);
	}

	/*@Override
	public ArrayList displayDetails() {
		IElectricInterfaceDAO ie=new ElectricImplDAO();
		ie.displayDetails();
		
	}*/
	
	
}
