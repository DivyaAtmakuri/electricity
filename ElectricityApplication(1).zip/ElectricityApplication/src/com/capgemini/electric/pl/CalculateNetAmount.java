package com.capgemini.electric.pl;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.electric.bean.ElectricBean;
import com.capgemini.electric.exception.ElectricException;
import com.capgemini.electric.service.*;

/**
 * Servlet implementation class CalculateNetAmount
 */
@WebServlet("/CalculateNetAmount")
public class CalculateNetAmount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ElectricBean e=new ElectricBean();
       IElectricInterface ie=new ElectricImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculateNetAmount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int fixedCharge=100;
		int consumerNo=Integer.parseInt(request.getParameter("consumerno"));
		double lastMonth=Double.parseDouble(request.getParameter("lastmonthread"));
		double currentMonth=Double.parseDouble(request.getParameter("currentmonthread"));
		
		
		try {
			if(ie.validate(consumerNo)){
				if(lastMonth>currentMonth){
					//response.getWriter().println("Last Month Reading Cannot be Greater than current month reading");
					response.sendRedirect("Electricity.html");
					}
					
					else
					{
					double units=Math.abs(lastMonth-currentMonth);
					double netAmount=(units*1.15)+fixedCharge;
					e.setConsumerNo(consumerNo);
					e.setUnits(units);
					e.setCurReading(currentMonth);
					e.setNetAmount(netAmount);
					try {
						ie.addBillDetails(e);
					} catch (ElectricException e1) {
						// TODO Auto-generated catch block
						System.out.println(e1);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						System.out.println(e1);
					}
					request.setAttribute("Elec", e);
					request.getRequestDispatcher("/DisplayDetails").forward(request, response);
					}
			}
			else
			{
				response.getWriter().println("<html><h3>Invalid Consumer Number</h3></html>");
			}
		}
		 catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (ElectricException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
	}

}
