package com.capgemini.electric.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.electric.bean.ConsumerBean;
import com.capgemini.electric.exception.ElectricException;
import com.capgemini.electric.service.ElectricImpl;
import com.capgemini.electric.service.IElectricInterface;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	IElectricInterface ie=new ElectricImpl();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ConsumerBean b=null;
		ArrayList l=null,bill=null;
		try{
		l=ie.displayConsumers();
		
		}
		catch(Exception e){
			System.out.println(e);
		}
		
		
		
		
		
		String op=request.getParameter("operation");
		if(op!=null){
		
		if(op.equals("billdetails"))
		{
			try{
				String con=(String)request.getParameter("consumerno");
				bill=ie.displayBills(Integer.parseInt(con));
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			request.setAttribute("Bill", bill);
			request.getRequestDispatcher("/showbill.jsp").forward(request,response);
		}
		}
		
		
		
		
		
		if(request.getParameter("search")!=null){
		if(request.getParameter("search").equals("search"))
		{
			
			try{
			if(ie.validate(Integer.parseInt(request.getParameter("consumer"))))
			{
				
				for(int i=0;i<l.size();i++){
					 b=(ConsumerBean)l.get(i);
					if(b.getConsumerNo().equals(request.getParameter("consumer")))
						break;
				}
				request.setAttribute("consumerno", b.getConsumerNo());
				request.setAttribute("consumername", b.getConsumerName());
				request.setAttribute("address", b.getAddress());
				request.getRequestDispatcher("/show_consumer.jsp").forward(request,response);
			}
			else
			{
				try{
				throw new ElectricException("Error");
				}
				catch(ElectricException e){
				request.setAttribute("consumerno",request.getParameter("consumer"));
				request.getRequestDispatcher("/error1.jsp").forward(request,response);
			}}
			}
			
			catch(Exception e){
				System.out.println(e);
			}
			
			
		}
		}
		else
		{
		
		request.setAttribute("list", l);
		request.getRequestDispatcher("/showConsumerList.jsp").forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	}

}
